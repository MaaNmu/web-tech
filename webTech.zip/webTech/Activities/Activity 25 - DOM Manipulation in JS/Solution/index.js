const list = document.querySelector('ul');

list.children[2].textContent = 'Changed!';
